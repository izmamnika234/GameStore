﻿using System.Collections.Generic;
using System.Linq;
using GameStore.BL.Interfaces;
using Serilog;

namespace GameStore.BL.Services
{
    public class ProductsService : IGamesService
    {
        private readonly IGamesRepository _gamesRepository;
        private readonly ILogger _logger;

        public ProductsService(IGamesRepository gamesRepository, ILogger logger)
        {
            _gamesRepository = gamesRepository;
            _logger = logger; 
        }

        public Games Create(Games products)
        
            var index = _gamesRepository.GetAll().OrderByDescending(x => x.Id).FirstOrDefault()?.Id;

            games.Id = (int)(index != null ? index + 1 : 1);

            return _gamesRepository.Create(games);
        }

        public Games Update(Games games)
        {
            return _gamesRepository.Update(games);
        }

        public Games Delete(int id)
        {
            return _gamesRepository.Delete(id);
        }

        public Games GetById(int id)
        {
            return _gamesRepository.GetById(id);
        }

        public IEnumerable<Games> GetAll()
        {
            return _gamesRepository.GetAll();
        }
    }
}
