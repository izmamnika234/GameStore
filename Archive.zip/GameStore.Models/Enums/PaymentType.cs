﻿namespace GameStore.Models.Enums
{
    public enum PaymentType
    {
        Cash = 0,
        CreditCard = 1
    }
}
