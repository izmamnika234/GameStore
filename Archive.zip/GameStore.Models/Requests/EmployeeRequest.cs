﻿using GameStore.Models.DTO;
using System.Collections.Generic;

namespace GameStore.Models.Requests
{
    public class EmployeeRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }
    }
}
