﻿namespace GameStore.Models.DTO
{
    public class GamesRequest
    {
        public string Name { get; set; }

        public double Price { get; set; }
    }
}