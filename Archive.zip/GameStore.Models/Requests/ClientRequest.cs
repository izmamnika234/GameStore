﻿namespace GameStore.Models.Enums

{
    public class ClientRequest
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public double Balance { get; set; }

        public PaymentType PaymentType { get; set; }
    }
}
