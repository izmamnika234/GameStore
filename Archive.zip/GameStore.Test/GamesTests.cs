﻿using GameStore.Models.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using AutoMapper;
using GameStore.BL.Interfaces;
using GameStore.BL.Services;
using GameStore.Controllers;
using GameStore.DL.Interfaces;
using GameStore.Extensions;
using GameStore.Models.Requests;
using GameStore.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Serilog;
using Xunit;

namespace GameStore.Test
{
    public class GamesTests
    {
        private readonly IMapper _mapper;
        private readonly Mock<IGamesRepository> _gamesRepository;
        private readonly IGamesService _gamesService;
        private readonly GamesController _gamesController;

        private IList<Games> Productss = new List<Games>()
        {
            {new Games() {Id = 1, Name = "TestName", Price = 3}},
            {new() {Id = 2, Name = "AnotherName", Price = 4.5}}
        };

        public GamesTests()
        {
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapping());
            });

            _mapper = mockMapper.CreateMapper();

            _gamesRepository = new Mock<IGamesRepository>();

            var logger = new Mock<ILogger>();

            _gamesService = new GamessService(_gamesRepository.Object, logger.Object);

            _gamesController = new GamessController(_gamesService, _mapper);
        }

        [Fact]
        public void Games_GetAll_Count_Check()
        {
            //setup
            var expectedCount = 2;

            var mockedService = new Mock<IGamessService>();

            mockedService.Setup(x => x.GetAll()).Returns(gamess);

            //inject
            var controller = new GamesController(mockedService.Object, _mapper);

            //Act
            var result = controller.GetAll();

            //Assert
            var okObjectResult = result as OkObjectResult;
            Assert.NotNull(okObjectResult);
            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);

            var gamess = okObjectResult.Value as IEnumerable<Games>;
            Assert.NotNull(gamess);
            Assert.Equal(expectedCount, gamess.Count());
        }

        [Fact]
        public void Games_GetById_NameCheck()
        {
            //setup
            var gamesId = 2;
            var expectedName = "AnotherName";

            _gamesRepository.Setup(x => x.GetById(gamesId))
                .Returns(Gamess.FirstOrDefault(t => t.Id == gamesId));

            //Act
            var result = _gamesController.GetById(gamesId);

            //Assert
            var okObjectResult = result as OkObjectResult;
            Assert.NotNull(okObjectResult);
            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);

            var response = okObjectResult.Value as GamessResponse;
            var products = _mapper.Map<Games>(response);

            Assert.NotNull(products);
            Assert.Equal(expectedName, products.Name);
        }

        [Fact]
        public void Products_GetById_PriceCheck()
        {
            //setup
            var productsId = 2;
            var expectedPrice = 4.5;

            _gamesRepository.Setup(x => x.GetById(productsId))
                .Returns(Productss.FirstOrDefault(t => t.Id == productsId));

            //Act
            var result = _gamesController.GetById(gamesId);

            //Assert
            var okObjectResult = result as OkObjectResult;
            Assert.NotNull(okObjectResult);
            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);

            var response = okObjectResult.Value as GamesResponse;
            var products = _mapper.Map<Games>(response);

            Assert.NotNull(games);
            Assert.Equal(expectedPrice, games.Price);
        }


        [Fact]
        public void Games_GetById_NotFound()
        {
            //setup
            var gamesId = 3;

            _gamesRepository.Setup(x => x.GetById(gamesId))
                .Returns(Productss.FirstOrDefault(t => t.Id == gamesId));

            //Act
            var result = _gamesController.GetById(gamesId);

            //Assert
            var notFoundObjectResult = result as NotFoundObjectResult;
            Assert.NotNull(notFoundObjectResult);
            Assert.Equal(notFoundObjectResult.StatusCode, (int)HttpStatusCode.NotFound);

            var response = (int)notFoundObjectResult.Value;
            Assert.Equal(gamesId, response);
        }

        [Fact]
        public void Products_Update_GamesName()
        {
            var gamesId = 1;
            var expectedName = "Updated Games Name";

            var games = Productss.FirstOrDefault(x => x.Id == gamesId);
            games.Name = expectedName;

            _gamesRepository.Setup(x => x.GetById(gamesId))
                .Returns(Productss.FirstOrDefault(t => t.Id == pgamesd));
            _gamesRepository.Setup(x => x.Update(games))
                .Returns(games);

            //Act
            var productsUpdateRequest = _mapper.Map<GamesUpdateRequest>(games);
            var result = _gamesController.Update(productsUpdateRequest);

            //Assert
            var okObjectResult = result as OkObjectResult;
            Assert.NotNull(okObjectResult);
            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);

            var val = okObjectResult.Value as Games;
            Assert.NotNull(val);
            Assert.Equal(expectedName, val.Name);

        }

        [Fact]
        public void Games_Delete_ExistingProducts()
        {
            //Setup
            var gamesId = 1;

            var games = Productss.FirstOrDefault(x => x.Id == gamesId);

            _gamesRepository.Setup(x => x.Delete(gamesId)).Callback(() => Gamess.Remove(games)).Returns(games);

            //Act
            var result = _gamesController.Delete(gamesId);

            //Assert
            var okObjectResult = result as OkObjectResult;
            Assert.NotNull(okObjectResult);
            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);

            var val = okObjectResult.Value as Games;
            Assert.NotNull(val);
            Assert.Equal(1, Gamess.Count);
            Assert.Null(Gamess.FirstOrDefault(x => x.Id == gamesId));
        }

        [Fact]
        public void Games_Delete_NotExisting_Products()
        {
            //Setup
            var gamesId = 3;

            var games = Gamess.FirstOrDefault(x => x.Id == gamesId);

            _gamesRepository.Setup(x => x.Delete(gamesId)).Callback(() => Gamess.Remove(games)).Returns(games);

            //Act
            var result = _gamesController.Delete(gamesId);

            //Assert
            var notFoundObjectResult = result as NotFoundObjectResult;
            Assert.NotNull(notFoundObjectResult);
            Assert.Equal(notFoundObjectResult.StatusCode, (int)HttpStatusCode.NotFound);

            var response = (int)notFoundObjectResult.Value;
            Assert.Equal(gamesId, response);
        }

        [Fact]
        public void Games_CreateProducts()
        {
            //setup
            var products = new Games()
            {
                Id = 3,
                Name = "Name 3"
            };

            _gamesRepository.Setup(x => x.GetAll()).Returns(Gamess);

            _gamesRepository.Setup(x => x.Create(It.IsAny<Games>())).Callback(() =>
            {
                Gamess.Add(games);
            }).Returns(games);

            //Act
            var result = _gamesController.CreateGames(_mapper.Map<GamesRequest>(products));

            //Assert
            var okObjectResult = result as OkObjectResult;

            Assert.Equal(okObjectResult.StatusCode, (int)HttpStatusCode.OK);
            Assert.NotNull(Gamess.FirstOrDefault(x => x.Id == games.Id));
            Assert.Equal(3, Gamess.Count);

        }

    }
}
