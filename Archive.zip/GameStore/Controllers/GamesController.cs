﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;

namespace GameStore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class GamesController : ControllerBase
    {
        private readonly IGameService _gamesService;
        private readonly IMapper _mapper;

        public GamesController(IGamesService gamesService, IMapper mapper)
        {
            _gamesService = (IGameService)gamesService;
            _mapper = mapper;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var result = _gamesService.GetAll();

            return Ok(result);
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            if (id <= 0) return BadRequest();

            var result = _gamesService.GetById(id);

            if (result == null) return NotFound(id);

            var response = _mapper.Map<GamesResponse>(result);

            return Ok(response);
        }

        [HttpPost("Create")]
        public IActionResult CreateGames([FromBody] GamesRequest gamesRequest)
        {
            if (gamesRequest == null) return BadRequest();

            var products = _mapper.Map<gameStore>(gamesRequest);

            var result = _gamesService.Create(gameStore);

            return Ok(products);
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            if (id <= 0) return BadRequest(id);

            var result = _gamesService.Delete(id);

            if (result == null) return NotFound(id);

            return Ok(result);
        }

        [HttpPost("Update")]
        public IActionResult Update([FromBody] GamesUpdateRequest gamesRequest)
        {
            if (gamesRequest == null) return BadRequest();

            var searchGames = _gamesService.GetById(gamesRequest.Id);

            if (searchGames == null) return NotFound(gamesRequest.Id);

            searchGames.Name = gamesRequest.Name;

            var result = _gamesService.Update(searchGames);

            return Ok(result);
        }

        public class GamesRequest
        {
        }

        public interface IGamesService
        {
        }

        private class gameStore
        {
        }

        private class GamesResponse
        {
        }
    }

    internal interface IGameService
    {
        object Create(GameStore products);
        object Create(object gameStore);
        object Delete(int id);
        object GetAll();
        object GetById(object id);
        object Update(object searchGames);
    }
}
