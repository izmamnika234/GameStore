﻿using AutoMapper;
using GameStore.Models.DTO;
using GameStore.Models.Requests;
using GameStore.Models.Responses;

namespace GameStore.Extensions
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {

            public AutoMapping()
            {
                CreateMap<Games, GamesResponse>().ReverseMap();
                CreateMap<GamesResponse, Games>().ReverseMap();
                CreateMap<GamesRequest, Games>().ReverseMap();

                CreateMap<Client, ClientResponse>().ReverseMap();
                CreateMap<ClientResponse, Client>().ReverseMap();
                CreateMap<ClientRequest, User>().ReverseMap();

                CreateMap<Employee, EmployeeResponse>().ReverseMap();
                CreateMap<EmployeeResponse, Employee>().ReverseMap();
                CreateMap<EmployeeRequest, Employee>().ReverseMap();


            }
    }
}
