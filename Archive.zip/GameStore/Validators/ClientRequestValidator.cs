﻿using System;
using System.Data;
using GameStore.Models.Requests;
using FluentValidation;

namespace GameStore.Validators
{
    public class ClientRequestValidator : AbstractValidator<ClientRequest>
    {
        public ClientRequestValidator()
        {
            RuleFor(x => x.Name).NotNull().NotEmpty().MinimumLength(2).MaximumLength(10);
            RuleFor(x => x.Balance).NotNull().NotEmpty();
        }

    }
}
