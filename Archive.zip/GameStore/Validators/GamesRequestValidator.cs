﻿using System;
using System.Data;
using GameStore.Models.Requests;
using FluentValidation;

namespace GameStore.Validators
{
    public class ProductsRequestValidator : AbstractValidator<GamesRequest>
    {
        public ProductsRequestValidator()
        {
            RuleFor(x => x.Name).NotNull().NotEmpty().MinimumLength(2).MaximumLength(10);
            RuleFor(x => x.Price).NotNull().NotEmpty();
        }

    }
}
