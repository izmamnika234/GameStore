﻿using GameStore.Models.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStore.DL.InMemoryDb
{
    public static class GamesInMemoryCollection
    {
        public static List<Games> ProductsDb = new List<Games>()
        {
            new Games()
            {
                Id = 11,
                Name = "NameA",
                Price = 4
            },
            new Games()
            {
                Id = 22,
                Name = "NameB",
                Price = 5
            },
            new Games()
            {
                Id = 33,
                Name = "NameC",
                Price = 6
            }
        };
    }
}
