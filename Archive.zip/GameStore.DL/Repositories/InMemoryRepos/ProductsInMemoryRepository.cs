﻿using GameStore.DL.InMemoryDb;
using GameStore.DL.Interfaces;
using GameStore.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameStore.DL.Repositories.InMemoryRepos
{

    public class GamesInMemoryRepository : IGamesRepository
    {

        public GamesInMemoryRepository()
        {

        }

        public Games Create(Games games)
        {
            GamesInMemoryCollection.ProductsDb.Add(games);

            return games;
        }

        public Games Delete(int id)
        {
            var products = GamesInMemoryCollection.GamesDb.FirstOrDefault(games => games.Id == id);

            GamesInMemoryCollection.GamesDb.Remove(games);

            return games;
        }

        public IEnumerable<Games> GetAll()
        {
            return GamesInMemoryCollection.GamesDb;
        }

        public Games GetById(int id)
        {
            return GamesInMemoryCollection.GamesDb.FirstOrDefault(x => x.Id == id);
        }

        public Games Update(Games games)
        {
            var result = GamesInMemoryCollection.GamesDb.FirstOrDefault(x => x.Id == games.Id);

            result.Name = games.Name;

            return result;
        }
    }
}



