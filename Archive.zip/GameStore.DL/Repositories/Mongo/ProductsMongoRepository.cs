﻿using GameStore.DL.Interfaces;
using GameStore.Models.Common;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System.Collections.Generic;
using Products = GameStore.Models.DTO.Products;

namespace GameStore.DL.Repositories.Mongo
{
    public class GamesMongoRepository : IGamesRepository
    {
        private readonly IMongoCollection<Games> _gamesCollection;

        public GamesMongoRepository(IOptions<MongoDbConfiguration> config)
        {
            var client = new MongoClient(config.Value.ConnectionString);
            var database = client.GetDatabase(config.Value.DatabaseName);

            _gamesCollection = database.GetCollection<Games>("Games");
        }

        public Games Create(Games games)
        {
            _gamesCollection.InsertOne(games);

            return products;
        }

        public Products Update(Games games)
        {
            _gamesCollection.ReplaceOne(gamesToReplace => gamesToReplace.Id == games.Id, games);
            return games;
        }

        public Products Delete(int id)
        {
            var games = GetById(id);
            _gamesCollection.DeleteOne(games => games.Id == id);

            return games;
        }

        public Games GetById(int id)
        {
            return _gamesCollection.Find(games => games.Id == id).FirstOrDefault();
        }

        public IEnumerable<Games> GetAll()
        {
            return _gamesCollection.Find(games => true).ToList();
        }
    }
}
