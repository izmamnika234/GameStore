﻿using GameStore.Models.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStore.DL.Interfaces
{
    public interface IGamesRepository
    {
        Games Create(Games games);

        Games Update(Games games);

        Games Delete(int id);

        Games GetById(int id);

        IEnumerable<Games> GetAll();
    }
}
